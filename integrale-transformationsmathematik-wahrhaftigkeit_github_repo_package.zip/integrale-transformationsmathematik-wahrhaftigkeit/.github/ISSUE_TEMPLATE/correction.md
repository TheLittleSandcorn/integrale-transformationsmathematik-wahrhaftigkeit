---
name: Korrektur / Correction
about: Fehler, Quelle oder Formel korrigieren
title: "[Correction] "
labels: correction
assignees: ''
---

## Betroffene Datei / Tabelle

## Aktuelle Aussage

## Vorgeschlagene Korrektur

## Quelle / Nachweis

## Statuscode

- [ ] H — historisch belegt
- [ ] F — mathematisch korrekt
- [ ] R — moderne Rekonstruktion
- [ ] K — ethische/kritische Einordnung
